﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Conversor_ST3.formulario
{
    /// <summary>
    /// Lógica interna para Converter.xaml
    /// </summary>
    public partial class Converter : Window
    {
        public Converter()
        {
            InitializeComponent();
        }
        private void btConverter_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                if (fromCombobox.SelectedIndex == 0)
                {
                    double real = Double.Parse(tbReal.Text);
                    double dolar = real * 4.93; // valor da cotação do dólar em 13/04/2023
                    tbDolar.Text = dolar.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: Favor colocar só número");
            }
            try
            {
                if (fromCombobox.SelectedIndex == 1)
                {
                    double dolar = Double.Parse(tbReal.Text);
                    double real = dolar * 0.20; //valor do dia 13/04/2023
                    tbDolar.Text = real.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: Favor colocar só número");
            }
        }

       
        private void btSair_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
